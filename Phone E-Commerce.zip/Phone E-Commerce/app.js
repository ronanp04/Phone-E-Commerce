var express = require("express");  
var app = express();

app.use( express.static( "views" ) )
app.use('/images', express.static('images'));

// Grab all data from json file and store it in cameras variable
var phones = require('./phones.json');

var fs = require('fs');
app.set('view engine', 'ejs'); // Template engine 
var bodyParser = require("body-parser"); // calling the body parser

app.use(bodyParser.urlencoded({extended:true}));

// render index page
app.get('/', function(req,res){
    
    res.render("index.ejs", {phones});
    console.log("Hello")
    
})

// Start the application
app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0" 
, function(){
  console.log("Express application working")
});

// Calls the add phone page
app.get('/add', function(req,res){ 
  res.render("add.ejs", {phones});
})

//posts info from the users inputs and stores in the application
app.post('/add', function(req,res){

var newProduct =     {
  itemNo : req.body.itemNo,
  title : req.body.title,
  description: req.body.description,
  price: req.body.price,
  brand: req.body.brand
}

// Make a variable which is a text version of the file to be edited
var myFile = JSON.stringify(phones)   //cameras is the json file

// calling the json file to be changed
fs.readFile('./phones.json', function readFileCallback(err, data){

  if (err){
    throw(err)
    
  } else {
    phones.push(newProduct);
          myFile = JSON.stringify(phones, null, 4)
          fs.writeFile('./phones.json', myFile, 'utf8', function(){})  //saves the updated file
        }
})
  res.redirect("/");
})

// Calls the add product page
app.get('/add', function(req,res){ 
  res.render("add.ejs", {phones});
})

// Calls the Show brands page
app.get('/brands', function(req,res){ 
  res.render("brands.ejs", {phones});
})

// function to show individual phone
app.get('/model/:name', function(req,res){

  function showIndividual(oneItem){
  return oneItem.title === req.params.name
}

var ourProduct = phones.filter(showIndividual)
res.render("model.ejs", {ourProduct});
  
})

// function to show individual makes !!!!!!!!!!!!!!!!!!!!!
app.get('/makes/:brand', function(req,res){
    
  function showBrand(oneBrand){
    return oneBrand.brand === req.params.brand
  }
  
  var ourMake = phones.filter(showBrand)
    res.render("makes.ejs", {ourMake});

  })




  /////////////////Instructions/////////////////

  // To start up the website, you need to be in app.js.
  // You then type in command "node app.js".
  //Go on google and type in the local server "localhost:3000"
  //Boom, website should start up!....